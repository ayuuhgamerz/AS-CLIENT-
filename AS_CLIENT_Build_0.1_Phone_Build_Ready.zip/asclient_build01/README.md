# AS CLIENT — Android source starter

Orange/black Android launcher shell for the AS CLIENT project.

## Current status
This is a source-code starter, not a finished Minecraft launcher or APK.
It provides a native Android project foundation and an initial Compose UI.
Minecraft runtime integration, Modrinth downloads, authentication, HUD mods,
recording, and launcher interoperability still require implementation/testing.

## Target
- Android
- Minecraft Java 1.21.11 profile target
- Fabric profile target
- Portable Modrinth `.mrpack` import/export planned
- Orange/black AS CLIENT identity

## Build
Open this folder in Android Studio with a compatible Android Gradle Plugin.
Use JDK 17+ and allow Gradle to sync. Then build the `app` debug APK.

## Planned milestones
1. Launcher shell and profile management
2. Modrinth API search and `.mrpack` import
3. Fabric profile/runtime integration
4. HUD/mod configuration and resource packs
5. Recording overlay controls and Android compatibility tests
