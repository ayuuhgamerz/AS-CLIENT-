# AS CLIENT feature roadmap

## Client profile
- [x] Android native project skeleton
- [x] Orange/black Compose launcher shell
- [ ] Minecraft 1.21.11 runtime integration
- [ ] Fabric loader installation and launch
- [ ] Offline username profile (single-player/local use; server policies vary)

## Modrinth
- [ ] Search projects via Modrinth API
- [ ] Filter by Minecraft 1.21.11 and Fabric
- [ ] Install mods with dependency resolution
- [ ] Import/export `.mrpack`
- [ ] Resource pack and shader pack manager

## HUD and PvP
- [ ] Custom crosshair
- [ ] Keystrokes
- [ ] Armor HUD
- [ ] Potion HUD
- [ ] CPS / FPS / ping
- [ ] Coordinates / direction / BPS
- [ ] Waypoints
- [ ] AS tab prefix (requires client-side mod or server-side tab formatting depending on environment)

## Visual / recording
- [ ] Cosmetics / local cape support
- [ ] Motion blur (renderer and Android compatibility dependent)
- [ ] Recording integration
- [ ] Hide launcher/touch overlay from recording where supported
