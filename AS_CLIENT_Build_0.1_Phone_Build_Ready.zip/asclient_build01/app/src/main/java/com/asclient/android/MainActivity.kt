package com.asclient.android

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Orange = Color(0xFFFF8500)
private val Background = Color(0xFF101010)
private val SurfaceDark = Color(0xFF1C1C1C)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { ASClientHome() }
    }
}

@Composable
fun ASClientHome() {
    var selected by remember { mutableStateOf("Home") }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Orange,
        background = Background,
        surface = SurfaceDark
    )) {
        Scaffold(containerColor = Background) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(20.dp)) {
                Text("AS CLIENT", color = Orange, fontSize = 30.sp, fontWeight = FontWeight.Black)
                Text("MINECRAFT JAVA • ANDROID", color = Color.LightGray, fontSize = 11.sp)
                Spacer(Modifier.height(22.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("Home", "Mods", "Packs", "Settings").forEach { tab ->
                        FilterChip(
                            selected = selected == tab,
                            onClick = { selected = tab },
                            label = { Text(tab) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = Orange,
                                selectedLabelColor = Color.Black
                            )
                        )
                    }
                }
                Spacer(Modifier.height(18.dp))
                when (selected) {
                    "Home" -> {
                        Panel("Minecraft Profile", "Target: Minecraft Java 1.21.11\nLoader target: Fabric")
                        Spacer(Modifier.height(12.dp))
                        Panel("Quick access", "Modrinth browser • Modpacks • Resource packs • Shader packs")
                        Spacer(Modifier.height(12.dp))
                        Panel("Client HUD plan", "Crosshair • Keystrokes • Armor • Potion • Waypoints • Motion Blur")
                    }
                    "Mods" -> Panel("Modrinth Mods", "Mod search and one-tap installation are planned for the next milestone.")
                    "Packs" -> Panel("Modpack Library", "Import/export .mrpack profiles and manage separate instances — planned.")
                    else -> Panel("Settings", "Orange theme • Offline profile • Recording overlay options — planned.")
                }
                Spacer(Modifier.weight(1f))
                Text("BUILD 0.1.0 • STARTER UI", color = Orange, fontSize = 10.sp)
            }
        }
    }
}

@Composable
private fun Panel(title: String, body: String) {
    Card(
        colors = CardDefaults.cardColors(containerColor = SurfaceDark),
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(Modifier.padding(16.dp)) {
            Text(title, color = Orange, fontWeight = FontWeight.Bold, fontSize = 17.sp)
            Spacer(Modifier.height(8.dp))
            Text(body, color = Color.White, lineHeight = 20.sp)
        }
    }
}
